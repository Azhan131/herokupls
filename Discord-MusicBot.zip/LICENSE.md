<h1 align="centre">License</h1>

1. You can't use your own credits
2. You can modify the codes(but you cant edit the credits)
3. You can't redistribute
4. You can use this code for public projects only
5. If you are making a Discord bot you can use it only as Private Bot. Not public
